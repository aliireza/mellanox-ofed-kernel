#ifndef _COMPAT_LINUX_VMALLOC_H
#define _COMPAT_LINUX_VMALLOC_H

#include "../../compat/config.h"

#include_next <linux/vmalloc.h>
#include <linux/overflow.h>

#endif /* _COMPAT_LINUX_VMALLOC_H */
