#ifndef _COMPAT_LINUX_CGROUP_RDMA_H
#define _COMPAT_LINUX_CGROUP_RDMA_H

#include "../../compat/config.h"

#ifdef HAVE_CGROUP_RDMA_H
#include_next <linux/cgroup_rdma.h>
#endif

#endif /* _COMPAT_LINUX_CGROUP_RDMA_H */
